function main() {


    time = new Date();
    now = time.getTime();



    update();
    render();

    requestAnimationFrame(main);


}
